<div align="center">
 
 [![IMG-20241116-WA0006-removebg-preview-1.png](https://i.postimg.cc/tCQMnfPh/IMG-20241116-WA0006-removebg-preview-1.png)](https://postimg.cc/Th09Zttw)

# Snack-Paradise 


Projeto realizado no 1º ano do curso a fim de ser entregue para a empresa IBM.
<hr>

### Link versão 1.0: https://joao-the-carvalho.github.io/Snack-Paradise-Site/Landing%20Page/

---

## Linguagens Utilizadas
![HTML5](https://img.shields.io/badge/html5-%23E34F26.svg?style=for-the-badge&logo=html5&logoColor=white)
![CSS3](https://img.shields.io/badge/css3-%231572B6.svg?style=for-the-badge&logo=css3&logoColor=white)
![JavaScript](https://img.shields.io/badge/javascript-%23323330.svg?style=for-the-badge&logo=javascript&logoColor=%23F7DF1E)
<hr>
</div>

## Participações:

### Antonio Bernardino de Sena Neto:
https://github.com/HakkaiDP

* Responsável pela revisão, reconstrução de telas junto do integrante João. E também realizou a montagem das telas: home, login e cardápio.

### Cesar Moreno Fernandes:
https://github.com/CesarMFernandes
* Realizou a tela de checkout.

### Eduardo Cavalcante:
https://github.com/MrEddie7

* Responsável pela codificação do arquivo "auxílio preferêncial"

### Giovanna Alves Martins Torres:
https://github.com/GiT0rres
* Responsável pela codificação da tela "Motoboy Vision".

### João Victor de Paiva Carvalho:
https://github.com/joao-the-carvalho
* Responsável pela codificação da tela Landing Page e auxílio na codificação das telas "Motoboy Vision", "Checkout" e "Sobre Nós"; Auxiliar na reconstrução de telas junto a Antonio.

---

## páginas

* Landing Page
* Menu
* Cardápio 
* Carrinho
* Login
* Checkout 
* Auxílio Preferêncial 
* Motoboy Vision
* Quem Somos
* Contato 
* Promoções


